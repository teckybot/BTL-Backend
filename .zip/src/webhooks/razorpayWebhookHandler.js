import crypto from "crypto";
import School from "../models/School.js";
import Payment from "../models/Payment.js";
import { generateSchoolId } from "../utils/idGenerator.js";
import { getCurrentSchoolSequence, incrementSchoolSequence } from "../services/sequenceService.js";
import { generateSchoolPDF } from "../services/pdfService.js";
import { sendSchoolBatchEmail } from "../services/mailService.js";
import { stateDistrictCodeMap } from "../constants/stateDistrictMap.js";

const handleRazorpayWebhook = async (req, res) => {
  const webhookSecret = process.env.RAZORPAY_WEBHOOK_SECRET;
  const signature = req.headers["x-razorpay-signature"];
  const body = req.body;

  const expectedSignature = crypto
    .createHmac("sha256", webhookSecret)
    .update(JSON.stringify(body))
    .digest("hex");

  if (expectedSignature !== signature) {
    console.log("❌ Webhook signature mismatch");
    return res.status(400).send("Invalid signature");
  }

  const event = body.event;

  // 🟢 1. Handle Successful Payment
  if (event === "payment.captured") {
    const payment = body.payload.payment.entity;
    const notes = payment.notes || {};
    
    const {
      schoolName,
      principalName,
      schoolContact,
      schoolEmail,
      coordinatorName,
      coordinatorNumber,
      coordinatorEmail,
      schoolAddress,
      schoolWebsite,
      state,
      district,
    } = notes;

    try {
      // Prevent duplicates
      const existing = await School.findOne({ schoolEmail });
      if (existing) {
        console.warn(`⚠️ Duplicate payment for school email ${schoolEmail}`);
        return res.status(200).send("Duplicate");
      }

      const stateCode = stateDistrictCodeMap[state]?.code;
      const districtCode = stateDistrictCodeMap[state]?.districts[district];
      if (!stateCode || !districtCode) {
        throw new Error("Invalid state or district in notes");
      }

      const currentSeq = await getCurrentSchoolSequence(stateCode, districtCode);
      const nextSeq = currentSeq + 1;
      const schoolRegId = generateSchoolId(state, district, nextSeq);

      // Save to DB
      const newSchool = new School({
        schoolName,
        principalName,
        schoolContact,
        schoolEmail,
        coordinatorName,
        coordinatorNumber,
        coordinatorEmail,
        schoolAddress,
        schoolWebsite,
        state,
        district,
        schoolRegId,
      });

      const pdfBuffer = await generateSchoolPDF(newSchool);
      const recipients = [
        {
          email: schoolEmail,
          name: coordinatorName,
          mergeData: {
            school_reg_id: schoolRegId,
            district,
            school_name: schoolName,
            coordinator_name: coordinatorName,
            state,
            coordinator_number: coordinatorNumber,
            principal_name: principalName,
          },
        },
      ];

      await sendSchoolBatchEmail({
        recipients,
        templateKey: "2518b.70f888d667329f26.k1.2cf64680-3e18-11f0-b2ad-ae9c7e0b6a9f.197263fbae8",
      });

      const committedSeq = await incrementSchoolSequence(stateCode, districtCode);
      if (committedSeq !== nextSeq) {
        newSchool.schoolRegId = generateSchoolId(state, district, committedSeq);
      }

      await newSchool.save();

      await Payment.create({
        schoolId: newSchool.schoolRegId,
        orderId: payment.order_id,
        paymentId: payment.id,
        amount: payment.amount / 100,
        verified: true,
        paymentDate: new Date(),
      });

      console.log(`✅ Payment success and registration completed for ${schoolEmail}`);
      return res.status(200).json({ status: "ok" });
    } catch (err) {
      console.error("❌ Error processing successful payment:", err);
      return res.status(500).send("Webhook handling failed");
    }
  }

  // 🔴 2. Handle Failed Payment
  if (event === "payment.failed") {
    const failedPayment = body.payload.payment.entity;
    const notes = failedPayment.notes || {};
    const schoolEmail = notes.schoolEmail || "UNKNOWN";

    try {
      await Payment.create({
        schoolId: notes.schoolId || "UNKNOWN",
        orderId: failedPayment.order_id,
        paymentId: failedPayment.id,
        amount: failedPayment.amount / 100,
        verified: false,
        paymentDate: new Date(),
        failureReason: failedPayment.error_description || "Unknown failure",
      });

      console.warn(`⚠️ Payment failed for ${schoolEmail}: ${failedPayment.error_description}`);
      return res.status(200).send("Payment failure recorded");
    } catch (err) {
      console.error("❌ Error recording failed payment:", err);
      return res.status(500).send("Webhook error on payment.failed");
    }
  }

  // 3. Other events (ignore)
  return res.status(200).send("Unhandled event");
};

export default handleRazorpayWebhook;
