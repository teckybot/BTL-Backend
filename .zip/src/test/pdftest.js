// testPdfGen.js
import { generateBatchTeamPDF,generateSchoolPDF } from '../services/pdfService.js';
import {downloadAIWorkshopPDF} from '../controllers/aiWorkshopPDFController.js';
import fs from 'fs';

const schoolData = {
  schoolRegId: 'SCH1234',
  schoolName: 'Test School',
  principalName: 'Dr. Principal',
  schoolEmail: 'school@example.com',
  coordinatorName: 'John Doe',
  coordinatorEmail: 'john@example.com',
  state: 'TestState',
  district: 'TestDistrict',
  schoolAddress: '3-135/14, F-1, MADHAVA ENCLAVE, GOLLAVANIPALEM, ROAD NO-1, AGANAMPUDI, VISAKHAPATNAM, 530053.'
};

const teamsData = [
  {
    teamRegId: 'TS001',
    event: 'ASB',
    teamSize: 4,
    members: [{ name: 'Alice' }, { name: 'Bob' }, { name: 'Carol' }, { name: 'Dave' }]
  },
  {
    teamRegId: 'TS002',
    event: 'ROB',
    teamSize: 3,
    members: [{ name: 'Eve' }, { name: 'Frank' }, { name: 'Grace' }]
  },
  {
    teamRegId: 'TS003',
    event: 'ROB',
    teamSize: 3,
    members: [{ name: 'Eve' }, { name: 'Frank' }, { name: 'Grace' }]
  },
  {
    teamRegId: 'TS004',
    event: 'ROB',
    teamSize: 3,
    members: [{ name: 'Eve' }, { name: 'Frank' }, { name: 'Grace' }]
  },
  {
    teamRegId: 'TS005',
    event: 'ROB',
    teamSize: 3,
    members: [{ name: 'Eve' }, { name: 'Frank' }, { name: 'Grace' }]
  },
  {
    teamRegId: 'TS006',
    event: 'ROB',
    teamSize: 3,
    members: [{ name: 'Eve' }, { name: 'Frank' }, { name: 'Grace' }]
  },
{
    teamRegId: 'TS007',
    event: 'ROB',
    teamSize: 3,
    members: [{ name: 'Eve' }, { name: 'Frank' }, { name: 'Grace' }]
  },
{
    teamRegId: 'TS008',
    event: 'ROB',
    teamSize: 3,
    members: [{ name: 'Eve' }, { name: 'Frank' }, { name: 'Grace' }]
  },
{
    teamRegId: 'TS009',
    event: 'ROB',
    teamSize: 3,
    members: [{ name: 'Eve' }, { name: 'Frank' }, { name: 'Grace' }]
  },

];

const eventCodeMap = {
  ASB: 'Astronomy',
  ROB: 'Robotics'
};


// generateSchoolPDF(schoolData)
//   .then(buffer => {
//     fs.writeFileSync('test_output.pdf', buffer);
//     console.log('PDF generated: test_output.pdf');
//   })
//   .catch(err => {
//     console.error('PDF generation failed:', err);
//   });

// generateBatchTeamPDF(schoolData,teamsData,eventCodeMap)
//   .then(buffer => {
//     fs.writeFileSync('test_output.pdf', buffer);
//     console.log('PDF generated: test_output.pdf');
//   })
//   .catch(err => {
//     console.error('PDF generation failed:', err);
//   });  


