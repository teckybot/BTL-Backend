// src/test/testSchoolValidation.js
import axios from "axios";
import dotenv from "dotenv";
dotenv.config();

const API_BASE = "http://localhost:5000/api/school/validate";

const testCases = [
  {
    label: "Valid input - should pass",
    payload: {
      schoolName: "GREENWOOD HIGH SCHOOL",
      principalName: "RAVI KUMAR",
      schoolContact: "9123456789",
      schoolEmail: "valid1@teckybot.com",
      coordinatorName: "SUNIL SHARMA",
      coordinatorNumber: "9876543210",
      coordinatorEmail: "valid2@teckybot.com",
      schoolAddress: "SCHOOL ROAD, HYDERABAD",
      state: "Telangana",
      district: "Hyderabad"
    }
  },
  {
    label: "Invalid email domain",
    payload: {
      schoolName: "ALPHA SCHOOL",
      principalName: "SURESH",
      schoolContact: "9123456789",
      schoolEmail: "invalid@invalid.com",
      coordinatorName: "RAKESH",
      coordinatorNumber: "9876543210",
      coordinatorEmail: "valid@teckybot.com",
      schoolAddress: "SOME PLACE",
      state: "Telangana",
      district: "Hyderabad"
    }
  },
  {
    label: "Phone number error",
    payload: {
      schoolName: "BETA SCHOOL",
      principalName: "KIRAN",
      schoolContact: "12345", // Invalid
      schoolEmail: "valid3@teckybot.com",
      coordinatorName: "ANIL",
      coordinatorNumber: "9876543210",
      coordinatorEmail: "valid4@teckybot.com",
      schoolAddress: "ADDRESS",
      state: "Telangana",
      district: "Hyderabad"
    }
  },
  {
    label: "Field not in ALL CAPS",
    payload: {
      schoolName: "Beta School", // not ALL CAPS
      principalName: "KIRAN",
      schoolContact: "9123456789",
      schoolEmail: "valid5@teckybot.com",
      coordinatorName: "ANIL",
      coordinatorNumber: "9876543210",
      coordinatorEmail: "valid6@teckybot.com",
      schoolAddress: "ADDRESS",
      state: "Telangana",
      district: "Hyderabad"
    }
  },
  {
    label: "Same email used for both",
    payload: {
      schoolName: "DELTA SCHOOL",
      principalName: "VIKRAM",
      schoolContact: "9123456789",
      schoolEmail: "same@teckybot.com",
      coordinatorName: "RAHUL",
      coordinatorNumber: "9876543210",
      coordinatorEmail: "same@teckybot.com",
      schoolAddress: "XYZ STREET",
      state: "Telangana",
      district: "Hyderabad"
    }
  },
  {
    label: "Duplicate email (existing entry)",
    payload: {
      schoolName: "OMEGA SCHOOL",
      principalName: "MAHESH",
      schoolContact: "9123456789",
      schoolEmail: "failed@example.com", // assume exists in DB
      coordinatorName: "RAHUL",
      coordinatorNumber: "9876543210",
      coordinatorEmail: "another@example.com",
      schoolAddress: "XYZ STREET",
      state: "Telangana",
      district: "Hyderabad"
    }
  }
];

const runTests = async () => {
  for (const test of testCases) {
    try {
      const res = await axios.post(API_BASE, test.payload);
      console.log(`${test.label} Passed\nResponse:`, res.data);
    } catch (err) {
      console.error(`${test.label} Failed\nError:`, err.response?.data || err.message);
    }
  }
};

runTests();
