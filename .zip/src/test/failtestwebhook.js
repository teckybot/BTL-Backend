import axios from "axios";
import crypto from "crypto";
import dotenv from "dotenv";
dotenv.config();

const failedPaymentPayload = {
  entity: "event",
  account_id: "ACC_TEST123",
  event: "payment.failed",
  contains: ["payment"],
  payload: {
    payment: {
      entity: {
        id: "PAY_FAILEDTEST001",
        entity: "payment",
        amount: 99900,
        currency: "INR",
        status: "failed",
        order_id: "ORDER_FAILEDTEST001",
        method: "UPI",
        email: "FAILED@EXAMPLE.COM",
        contact: "+910000000000",
        notes: {
          state: "TELANGANA",
          district: "HYDERABAD",
          schoolName: "FAILED TEST SCHOOL",
          schoolEmail: "FAILED@EXAMPLE.COM",
          principalName: "FAILURE PRINCIPAL",
          schoolAddress: "FAILURE ADDRESS",
          schoolContact: "0000000000",
          schoolWebsite: "",
          coordinatorName: "FAIL COORDINATOR",
          coordinatorEmail: "FAILCOORDINATOR@EXAMPLE.COM",
          coordinatorNumber: "9000000000",
        },
        error_description: "PAYMENT DECLINED BY BANK",
        created_at: Math.floor(Date.now() / 1000),
      },
    },
  },
  created_at: Math.floor(Date.now() / 1000),
};

// Generate the signature
const secret = process.env.RAZORPAY_WEBHOOK_SECRET;
const bodyString = JSON.stringify(failedPaymentPayload);
const signature = crypto
  .createHmac("sha256", secret)
  .update(bodyString)
  .digest("hex");

// Send webhook request
axios
  .post("http://localhost:5000/api/payments/webhook", bodyString, {
    headers: {
      "Content-Type": "application/json",
      "X-Razorpay-Signature": signature,
    },
  })
  .then((res) => {
    console.log("Webhook sent! Response:", res.data);
  })
  .catch((err) => {
    console.error("Error sending webhook:", err.response?.data || err.message);
  });
