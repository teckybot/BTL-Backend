import { generateAIWorkshopPDF } from '../services/pdfService.js';
import fs from 'fs';

const registrationData = {
  registrationId: 'AIW007',
  name: 'JANE DOE',
  email: 'jane.doe@gmail.com',
  contact: '9876543210',
  school: 'EXAMPLE SCHOOL',
};

generateAIWorkshopPDF(registrationData)
  .then(buffer => {
    fs.writeFileSync('test_aiworkshop_output.pdf', buffer);
    console.log('AI Workshop PDF generated: test_aiworkshop_output.pdf');
  })
  .catch(err => {
    console.error('AI Workshop PDF generation failed:', err);
  }); 