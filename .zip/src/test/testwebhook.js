import crypto from "crypto";
import axios from "axios";

// Use the same webhook secret from your .env
const secret = "schoolregemail"; // Replace if your secret is different

// Sample payload similar to what Razorpay sends
const payload = {
  entity: "event",
  account_id: "acc_NRw7nznpmb1jPh",
  event: "payment.captured",
  contains: ["payment"],
  payload: {
    payment: {
      entity: {
        id: "pay_TEST123456",
        entity: "payment",
        amount: 99900,
        currency: "INR",
        status: "captured",
        order_id: "order_TEST987654",
        method: "upi",
        vpa: "success@razorpay",
        email: "siddharthsiddhu124@gmail.com",
        contact: "+911234567890",
        notes: {
          state: "Telangana",
          district: "Jogulamba Gadwal",
          schoolName: "ABC HIGH SCHOOL",
          schoolEmail: "siddharthsiddhu124@gmail.com",
          principalName: "MALLIK",
          schoolAddress: "A",
          schoolContact: "6423233223",
          schoolWebsite: "",
          coordinatorName: "A",
          coordinatorEmail: "sssmallik143@gmail.com",
          coordinatorNumber: "7249247525",
        },
        fee: 2358,
        tax: 360,
        created_at: Math.floor(Date.now() / 1000),
        upi: {
          vpa: "success@razorpay",
        },
      },
    },
  },
  created_at: Math.floor(Date.now() / 1000),
};

// Convert payload to raw string
const rawBody = JSON.stringify(payload);

// Generate signature
const signature = crypto
  .createHmac("sha256", secret)
  .update(rawBody)
  .digest("hex");

// Send POST request to your local webhook endpoint
(async () => {
  try {
    const response = await axios.post(
      "http://localhost:5000/api/payments/webhook",
      rawBody,
      {
        headers: {
          "Content-Type": "application/json",
          "X-Razorpay-Signature": signature,
        },
      }
    );
    console.log("Webhook sent! Response:", response.data);
  } catch (err) {
    console.error("Error sending webhook:", err?.response?.data || err.message);
  }
})();
